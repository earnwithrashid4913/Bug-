import { sendReply, formatError } from '../lib/helpers.js';
import axios from 'axios';
import yts from 'yt-search';

export default {
    name: 'play',
    aliases: [],
    description: 'Rechercher et télécharger une musique depuis YouTube',
    
    async execute({ sock, msg, args, phoneNumber, userSettings }) {
        const jid = msg.key.remoteJid;
        
        // Extraire la requête
        let query = '';
        if (args && args.length > 0) {
            query = args.join(' ');
        } else {
            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const fullCommand = body.slice(userSettings.prefix.length).trim();
            const commandName = fullCommand.split(/\s+/)[0].toLowerCase();
            query = fullCommand.slice(commandName.length).trim();
        }
        
        if (!query) {
            return sendReply(sock, jid, '❌ Titre de musique requis\nExemple: play Imagine Dragons', { quoted: msg });
        }

        try {
            await sock.sendMessage(jid, { react: { text: '🔍', key: msg.key } }).catch(() => {});

            // Rechercher la vidéo
            const searchResults = await yts(query);
            if (!searchResults?.videos?.length) {
                throw new Error('Aucun résultat trouvé pour: ' + query);
            }

            const video = searchResults.videos[0];
            const youtubeUrl = video.url;
            
            await sock.sendMessage(jid, { react: { text: '⬇️', key: msg.key } }).catch(() => {});

            // Envoyer les infos de la vidéo
            await sock.sendMessage(jid, {
                image: { url: video.thumbnail },
                caption: `🎵 *${video.title}*\n👤 ${video.author.name}\n⏱️ ${video.duration.timestamp}\n🔄 Téléchargement en cours...`
            }, { quoted: msg }).catch(() => {});

            // Fonction pour récupérer les données audio avec l'API Hector
            async function fetchAudioData(videoUrl) {
                const HECTOR_API_URL = 'https://yt-dl.officialhectormanuel.workers.dev/';
                
                const apiUrl = `${HECTOR_API_URL}?url=${encodeURIComponent(videoUrl)}`;
                const response = await axios.get(apiUrl, {
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });
                
                if (!response.data?.status || !response.data?.audio) {
                    throw new Error('API response invalide ou audio non disponible');
                }
                return response.data;
            }

            // Récupérer les données audio
            const audioData = await fetchAudioData(youtubeUrl);
            
            if (!audioData.audio) {
                throw new Error('Aucun lien audio trouvé');
            }

            // Envoyer l'audio
            await sock.sendMessage(jid, {
                audio: { url: audioData.audio },
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: msg });

            await sock.sendMessage(jid, { react: { text: '✅', key: msg.key } }).catch(() => {});
            
        } catch (error) {
            console.error('Erreur complète:', error);
            await sock.sendMessage(jid, { react: { text: '❌', key: msg.key } }).catch(() => {});
            
            let errorMessage = '❌ Erreur lors du téléchargement\n';
            if (error.message.includes('timeout')) {
                errorMessage += 'La requête a expiré. Réessaie plus tard.';
            } else if (error.response?.status === 404) {
                errorMessage += 'API non disponible.';
            } else {
                errorMessage += error.message;
            }
            
            await sendReply(sock, jid, errorMessage, { quoted: msg });
        }
    }
};