import { font } from '../lib/helpers.js';
import fs from 'fs';
import path from 'path';

export default {
    name: 'menu',
    aliases: ['menu', 'list'],
    description: '✨ Affiche tous les commandes disponibles ✨',
    
    async execute({ sock, msg, phoneNumber, userSettings }) {
        const jid = msg.key.remoteJid;
        
        // Menu text stylisé
        const menuText = `
┏━✰━━━━━━━━━━━━━━━━✰━┓
    ☆☆☆ 𝐋𝐎𝐕𝐄 - 𝐗 𝐃 - 𝐁𝐎𝐓 ☆☆☆
┗━✰━━━━━━━━━━━━━━━━✰━┛
┏━━━━━━━━━━━━━━━━━✰
┃ ✦ 𝐘𝐨𝐮𝐫 𝐔𝐥𝐭𝐢𝐦𝐚𝐭𝐞 𝐋𝐨𝐯𝐞 𝐀𝐬𝐬𝐢𝐬𝐭𝐚𝐧𝐭
┃ ✦ 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : 𝐆𝐨𝐚𝐭𝐬𝐌𝐨𝐝𝐬 
┠ ✦ 𝐍𝐚𝐦𝐞 : ${userSettings.bot_name}
┠ ✦ 𝐏𝐫𝐞𝐟𝐢𝐱𝐞 : ${userSettings.prefix}
┠ ✦ 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 1.0.0
┗━━━━━━━━━━━━━━━━━━━━━━✰

◈ 𝐆𝐄𝐍𝐄𝐑𝐀𝐋 𝐓𝐎𝐎𝐋𝐒 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .menu
┠ ✧ .setname 
┠ ✧ .setprefix
┠ ✧ .alive
┠ ✧ .ping
┠ ✧ .private
┠ ✧ .public
┠ ✧ .sudo
┠ ✧ .delsudo
┠ ✧ .sudolist
┗━━━━━━━━━━━━━━━━━━━━━◈

◈ 𝐀𝐑𝐓𝐈𝐅𝐈𝐂𝐈𝐀𝐋 𝐈𝐍𝐓𝐄𝐋𝐋𝐈𝐆𝐄𝐍𝐂𝐄 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .love
┗━━━━━━━━━━━━━━━━━━━━━◈

◈ 𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐈𝐎𝐍𝐒 𝐀𝐑𝐄𝐍𝐀 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .antimention
┠ ✧ .antilink
┠ ✧ .antispam
┠ ✧ .antitag
┠ ✧ .autoreact
┠ ✧ .autostatus
┠ ✧ .autowrite
┠ ✧ .antidelete
┠ ✧ .hey (vv)
┠ ✧ .save
┠ ✧ .welcome
┠ ✧ .goodbye
┠ ✧ .idch
┠ ✧ .warnings
┗━━━━━━━━━━━━━━━━━━━━━◈

◈ 𝐌𝐄𝐃𝐈𝐀 𝐔𝐋𝐓𝐑𝐀 𝐂𝐎𝐑𝐄 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .store 
┠ ✧ .ad 
┠ ✧ .vd 
┠ ✧ .list
┠ ✧ .sticker
┠ ✧ .getpp
┠ ✧ .setpp
┠ ✧ .toimg
┠ ✧ .tovid
┗━━━━━━━━━━━━━━━━━━━━━◈

◈ 𝐆𝐑𝐎𝐔𝐏𝐒 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .gname
┠ ✧ .gdesc
┠ ✧ .kick
┠ ✧ .add
┠ ✧ .promote
┠ ✧ .demote
┠ ✧ .purge
┠ ✧ .tag
┠ ✧ .tagall
┠ ✧ .jid
┠ ✧ .kickall
┠ ✧ .lock
┠ ✧ .unlock
┠ ✧ .grouplink
┠ ✧ .antidemote
┠ ✧ .antipromote
┠ ✧ .demoteall
┠ ✧ .autopromote
┗━━━━━━━━━━━━━━━━━━━━━◈

◈ 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .play
┠ ✧ .ytmp3
┠ ✧ .ytmp4
┗━━━━━━━━━━━━━━━━━━━━━◈

◈ 𝐓𝐎𝐎𝐋𝐒 𝐗 𝐓𝐎𝐎𝐋𝐒 ◈
┏━━━━━━━━━━━━━◈
┠ ✧ .fancy
┠ ✧ .encrypt
┠ ✧ .encrypt2
┠ ✧ .tempmail
┠ ✧ .getmail
┗━━━━━━━━━━━━━━━━━━━━━◈
┏━━━━━━━━━━━━━━━━━━━━━━✰
┃ 𝐓𝐡𝐞 𝐋𝐨𝐯𝐞 𝐎𝐟 𝐘𝐨𝐮𝐫 𝐋𝐢𝐟𝐞 𝐈𝐬 𝐌𝐞
┃ 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐆𝐨𝐚𝐭𝐬𝐌𝐨𝐝𝐬-𝐎𝐧𝐥𝐲𝐅!𝐗𝐀??
┗━━━━━━━━━━━━━━━━━━━━━━✰`;

        try {
            // Application du style font si disponible
            const finalMenu = font ? font(menuText) : menuText;
            
            const imagePath = path.join(process.cwd(), 'media', 'menu.jpg');  
            const audioPath = path.join(process.cwd(), 'media', 'menu.mp3');  

            // Vérification des fichiers média
            if (!fs.existsSync(imagePath)) {
                console.warn(`⚠️ [${phoneNumber}] Fichier image introuvable: ${imagePath}`);
                throw new Error('IMAGE_NOT_FOUND');
            }

            if (!fs.existsSync(audioPath)) {
                console.warn(`⚠️ [${phoneNumber}] Fichier audio introuvable: ${audioPath}`);
                throw new Error('AUDIO_NOT_FOUND');
            }

            // Réaction avec cœur
            await sock.sendMessage(jid, { 
                react: { text: '❤️', key: msg.key } 
            });

            // Envoi de l'image avec le menu
            await sock.sendMessage(jid, {
                image: fs.readFileSync(imagePath),
                caption: finalMenu,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: '𝐋 𝐎 𝐕 𝐄 - 𝐗 𝐃 - 𝐁 𝐎 𝐓', // ✅ Correction : guillemet fermant ajouté
                        newsletterJid: '120363402350289449@newsletter'
                    }
                }
            });

            console.log(`✅ [${phoneNumber}] Menu image envoyé avec succès`);

            // Petit délai avant l'audio
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Envoi de l'audio
            await sock.sendMessage(jid, {
                audio: fs.readFileSync(audioPath),
                mimetype: 'audio/mpeg',
                ptt: false
            });

            console.log(`🎵 [${phoneNumber}] Audio menu envoyé avec succès`);

        } catch (error) {
            console.error(`❌ [${phoneNumber}] Erreur envoi du menu avec média:`, error.message);
            
            // Fallback en mode texte uniquement
            try {
                const fallbackText = font ? font(menuText) : menuText;
                await sock.sendMessage(jid, { 
                    text: fallbackText,
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true
                    }
                });
                console.log(`📝 [${phoneNumber}] Menu envoyé en mode texte (fallback)`);
            } catch (fallbackError) {
                console.error(`💔 [${phoneNumber}] Échec complet de l'envoi du menu:`, fallbackError.message);
                await sock.sendMessage(jid, { 
                    text: '❌ Désolé, une erreur est survenue lors de l\'affichage du menu. Veuillez réessayer plus tard.' 
                });
            }
        }
    }
};