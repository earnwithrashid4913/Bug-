import { sendReply, formatError } from '../lib/helpers.js';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';

export default {
    name: 'hey',
    aliases: ['viewonce', 'revealonce'],
    description: 'Reveal view once messages (sent privately)',
    usage: 'hey (reply to a view once message)',

    async execute({ sock, msg, phoneNumber }) {
        const jid = msg.key.remoteJid;
        const senderJid = msg.key.participant || msg.key.remoteJid;
        
        // Vérifier si c'est un message privé ou groupe
        const isGroup = jid.endsWith('@g.us');
        
        if (!msg.message.extendedTextMessage?.contextInfo?.quotedMessage) {
            if (isGroup) {
                // Réaction ❎ pour erreur
                await sock.sendMessage(jid, {
                    react: { text: '❎', key: msg.key }
                });
                // Envoi de l'erreur en DM
                await sock.sendMessage(senderJid, { 
                    text: formatError('❌ Répondez à un message view once') 
                }, { quoted: null });
            } else {
                await sock.sendMessage(senderJid, { 
                    text: formatError('❌ Répondez à un message view once') 
                }, { quoted: null });
            }
            return;
        }

        const quotedMessage = msg.message.extendedTextMessage.contextInfo.quotedMessage;
        
        const quotedImage = quotedMessage.imageMessage;
        const quotedVideo = quotedMessage.videoMessage;

        try {
            if (quotedImage && quotedImage.viewOnce) {
                console.log(`🔍 [${phoneNumber}] Revealing view once: IMAGE (private)`);
                
                const stream = await downloadContentFromMessage(quotedImage, 'image');
                let buffer = Buffer.from([]);
                
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                
                if (buffer.length === 0) {
                    throw new Error('Empty buffer - cannot download image');
                }

                // En-tête pour le DM
                const revealCaption = `🔓 *VIEW ONCE REVEALED*

📸 Type: *Image*
👤 Demandé par: *${phoneNumber}*
📅 Date: *${new Date().toLocaleString()}*
${quotedImage.caption ? `📝 Légende: *${quotedImage.caption}*` : ''}

Powered By DarkMods 🔮`;

                // Envoyer en DM
                await sock.sendMessage(senderJid, {
                    image: buffer,
                    fileName: 'view_once_revealed.jpg',
                    caption: revealCaption
                }, { quoted: null });

                // Réaction ✔️ pour succès
                if (isGroup) {
                    await sock.sendMessage(jid, {
                        react: { text: '✔️', key: msg.key }
                    });
                }

                console.log(`✅ [${phoneNumber}] View once image revealed successfully`);
                return;
            }

            if (quotedVideo && quotedVideo.viewOnce) {
                console.log(`🔍 [${phoneNumber}] Revealing view once: VIDEO (private)`);
                
                const stream = await downloadContentFromMessage(quotedVideo, 'video');
                let buffer = Buffer.from([]);
                
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                
                if (buffer.length === 0) {
                    throw new Error('Empty buffer - cannot download video');
                }

                const revealCaption = `🔓 *VIEW ONCE REVEALED*

🎥 Type: *Vidéo*
👤 Demandé par: *${phoneNumber}*
📅 Date: *${new Date().toLocaleString()}*
${quotedVideo.caption ? `📝 Légende: *${quotedVideo.caption}*` : ''}

Powered By DarkMods 🔮`;

                // Envoyer en DM
                await sock.sendMessage(senderJid, {
                    video: buffer,
                    fileName: 'view_once_revealed.mp4',
                    caption: revealCaption,
                    mimetype: 'video/mp4'
                }, { quoted: null });

                // Réaction ✔️ pour succès
                if (isGroup) {
                    await sock.sendMessage(jid, {
                        react: { text: '✔️', key: msg.key }
                    });
                }

                console.log(`✅ [${phoneNumber}] View once video revealed successfully`);
                return;
            }

            // Message view once invalide
            if (isGroup) {
                await sock.sendMessage(jid, {
                    react: { text: '❎', key: msg.key }
                });
                await sock.sendMessage(senderJid, { 
                    text: formatError('❌ Message view once invalide') 
                }, { quoted: null });
            } else {
                await sock.sendMessage(senderJid, { 
                    text: formatError('❌ Message view once invalide') 
                }, { quoted: null });
            }

        } catch (error) {
            console.error(`❌ [${phoneNumber}] View once reveal error:`, error);
            
            let errorMsg = '❌ Échec de récupération';
            
            if (error.message.includes('Empty buffer')) {
                errorMsg = '❌ Impossible de télécharger le média';
            } else if (error.message.includes('not found')) {
                errorMsg = '❌ Message view once expiré';
            }
            
            // Envoyer l'erreur en DM
            await sock.sendMessage(senderJid, {
                text: formatError(`${errorMsg}\nDétail: ${error.message}`)
            }, { quoted: null });
            
            // Réaction ❎ pour erreur
            if (isGroup) {
                await sock.sendMessage(jid, {
                    react: { text: '❎', key: msg.key }
                });
            }
        }
    }
};