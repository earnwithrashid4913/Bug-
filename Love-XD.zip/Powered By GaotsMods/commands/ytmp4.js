import { sendReply, formatError } from '../lib/helpers.js';
import axios from 'axios';
import yts from 'yt-search';

export default {
    name: 'ytmp4',
    aliases: ['video', 'ytvideo'],
    description: 'Rechercher et télécharger une vidéo depuis YouTube',
    
    async execute({ sock, msg, args, phoneNumber, userSettings }) {
        const jid = msg.key.remoteJid;
        
        // Extraire la requête
        let query = '';
        if (args && args.length > 0) {
            query = args.join(' ');
        } else {
            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const fullCommand = body.slice(userSettings.prefix.length).trim();
            const commandName = fullCommand.split(/\s+/)[0].toLowerCase();
            query = fullCommand.slice(commandName.length).trim();
        }
        
        if (!query) {
            return sendReply(sock, jid, '❌ Titre de vidéo requis\nExemple: ytmp4 Imagine Dragons Believer', { quoted: msg });
        }

        try {
            await sock.sendMessage(jid, { react: { text: '🔍', key: msg.key } }).catch(() => {});

            // Rechercher la vidéo
            const searchResults = await yts(query);
            if (!searchResults?.videos?.length) {
                throw new Error('Aucun résultat trouvé pour: ' + query);
            }

            const video = searchResults.videos[0];
            const youtubeUrl = video.url;
            
            await sock.sendMessage(jid, { react: { text: '⬇️', key: msg.key } }).catch(() => {});

            // Fonction pour récupérer les données vidéo avec l'API Hector
            async function fetchVideoData(videoUrl) {
                const HECTOR_API_URL = 'https://yt-dl.officialhectormanuel.workers.dev/';
                
                const apiUrl = `${HECTOR_API_URL}?url=${encodeURIComponent(videoUrl)}`;
                const response = await axios.get(apiUrl, {
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });
                
                if (!response.data?.status) {
                    throw new Error('API response invalide');
                }
                return response.data;
            }

            // Récupérer les données vidéo
            const videoData = await fetchVideoData(youtubeUrl);
            
            // Déterminer la meilleure qualité vidéo disponible
            const qualities = ['1080', '720', '480', '360', '240', '144'];
            let videoUrl = null;
            let selectedQuality = null;
            
            for (const quality of qualities) {
                if (videoData.videos && videoData.videos[quality]) {
                    videoUrl = videoData.videos[quality];
                    selectedQuality = quality;
                    break;
                }
            }
            
            if (!videoUrl) {
                throw new Error('Aucune qualité vidéo disponible');
            }

            // Envoyer les infos de la vidéo
            const caption = `🎬 *${videoData.title || video.title}*\n` +
                           `👤 ${video.author.name}\n` +
                           `⏱️ ${video.duration.timestamp}\n` +
                           `📹 Qualité: ${selectedQuality}p\n` +
                           `🔄 Téléchargement en cours...`;
            
            await sock.sendMessage(jid, {
                image: { url: videoData.thumbnail || video.thumbnail },
                caption: caption
            }, { quoted: msg }).catch(() => {});

            // Envoyer la vidéo
            await sock.sendMessage(jid, {
                video: { url: videoUrl },
                mimetype: 'video/mp4',
                caption: `✅ *${videoData.title || video.title}*\n📹 Qualité: ${selectedQuality}p`
            }, { quoted: msg });

            await sock.sendMessage(jid, { react: { text: '✅', key: msg.key } }).catch(() => {});
            
        } catch (error) {
            console.error('Erreur vidéo:', error);
            await sock.sendMessage(jid, { react: { text: '❌', key: msg.key } }).catch(() => {});
            
            let errorMessage = '❌ Erreur lors du téléchargement de la vidéo\n';
            if (error.message.includes('timeout')) {
                errorMessage += 'La requête a expiré. Réessaie plus tard.';
            } else if (error.response?.status === 404) {
                errorMessage += 'API non disponible.';
            } else {
                errorMessage += error.message;
            }
            
            await sendReply(sock, jid, errorMessage, { quoted: msg });
        }
    }
};