import { sendReply, formatError } from '../lib/helpers.js';
import axios from 'axios';

export default {
    name: 'ytmp3',
    aliases: ['audio', 'mp3'],
    description: 'Télécharger l\'audio d\'une vidéo YouTube',
    
    async execute({ sock, msg, args, phoneNumber, userSettings }) {
        const jid = msg.key.remoteJid;
        
        // Extraire l'URL
        let url = '';
        if (args && args.length > 0) {
            url = args[0];
        } else {
            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const fullCommand = body.slice(userSettings.prefix.length).trim();
            const commandName = fullCommand.split(/\s+/)[0].toLowerCase();
            url = fullCommand.slice(commandName.length).trim();
        }
        
        if (!url) {
            return sendReply(sock, jid, '❌ URL YouTube requise\nExemple: ytmp3 https://youtu.be/...', { quoted: msg });
        }

        // Vérifier si c'est une URL YouTube valide
        const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/;
        if (!youtubeRegex.test(url)) {
            return sendReply(sock, jid, '❌ URL YouTube invalide', { quoted: msg });
        }

        try {
            await sock.sendMessage(jid, { react: { text: '⬇️', key: msg.key } }).catch(() => {});

            // Utiliser l'API Hector
            const HECTOR_API_URL = 'https://yt-dl.officialhectormanuel.workers.dev/';
            const apiUrl = `${HECTOR_API_URL}?url=${encodeURIComponent(url)}`;
            
            const response = await axios.get(apiUrl, { 
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
            });
            
            // Vérifier la réponse
            if (!response.data?.status || !response.data?.audio) {
                throw new Error('Audio non trouvé pour cette vidéo');
            }

            const videoData = response.data;

            // Envoyer les infos avant l'audio (optionnel)
            if (videoData.thumbnail && videoData.title) {
                await sock.sendMessage(jid, {
                    image: { url: videoData.thumbnail },
                    caption: `🎵 *${videoData.title}*\n🔄 Téléchargement de l'audio...`
                }, { quoted: msg }).catch(() => {});
            }

            // Envoyer l'audio
            await sock.sendMessage(jid, {
                audio: { url: videoData.audio },
                mimetype: 'audio/mpeg',
                filename: `${videoData.title || 'audio'}.mp3`
            }, { quoted: msg });

            await sock.sendMessage(jid, { react: { text: '✅', key: msg.key } }).catch(() => {});
            
        } catch (error) {
            console.error('Erreur ytmp3:', error.message);
            await sock.sendMessage(jid, { react: { text: '❌', key: msg.key } }).catch(() => {});
            
            let errorMessage = '❌ Erreur lors du téléchargement\n';
            if (error.message.includes('timeout')) {
                errorMessage += 'La requête a expiré. Réessaie plus tard.';
            } else if (error.response?.status === 404) {
                errorMessage += 'API non disponible.';
            } else {
                errorMessage += error.message;
            }
            
            await sendReply(sock, jid, errorMessage, { quoted: msg });
        }
    }
};