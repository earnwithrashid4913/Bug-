import { 
  makeWASocket, 
  useMultiFileAuthState, 
  fetchLatestBaileysVersion, 
  DisconnectReason,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import http from 'http';
import chalk from 'chalk';
import pino from 'pino';
import fs from 'fs';
import path from 'path';
import NodeCache from 'node-cache';
import readline from 'readline';

// Import de vos modules existants
import config from './config.js';
import Database from './lib/database.js';
import { isAdmin, isOwner, checkPermissions } from './lib/isAdmin.js';
import { safeSend, safeReact, safePresence } from './lib/safeSend.js';
import { font, sendReply, sendMessage, buildAdReplyContext } from './lib/helpers.js';
import sudoManager from './lib/sudoManager.js';
import botTracker from './lib/botTracker.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Cache pour les groupes
const groupCache = new NodeCache({ stdTTL: 10 * 60, checkperiod: 120, useClones: false });

// Variables globales du bot
let sock = null;
let isConnected = false;
let welcomeMessageSent = false;
let welcomeMessageSentSession = false;
let connectionAttempts = 0;
const commands = new Map();
const userWarnings = new Map();
const lastMessageTime = new Map();

function ask(questionText) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(questionText, answer => {
    rl.close();
    resolve(answer.trim());
  }));
}

// Chargement des commandes
async function loadCommands() {
  console.log('📚 Loading commands...');
  commands.clear();
  
  const commandsDir = path.join(process.cwd(), 'commands');
  if (!fs.existsSync(commandsDir)) {
    console.log('📁 Creating commands directory');
    fs.mkdirSync(commandsDir, { recursive: true });
    return;
  }

  const files = fs.readdirSync(commandsDir).filter(file => file.endsWith('.js'));
  
  for (const file of files) {
    try {
      const commandPath = path.join(commandsDir, file);
      const commandUrl = `file://${commandPath}?update=${Date.now()}`;
      
      const command = await import(commandUrl);
      const cmd = command.default || command;
      
      if (cmd.name) {
        commands.set(cmd.name.toLowerCase(), cmd);
        
        if (cmd.aliases && Array.isArray(cmd.aliases)) {
          cmd.aliases.forEach(alias => {
            commands.set(alias.toLowerCase(), cmd);
          });
        }
        
        console.log(`♦️ Command Loaded : ${cmd.name}`);
      }
    } catch (error) {
      console.error(`💔 Error Loading Commands ${file}:`, error.message);
    }
  }
  
  console.log(`🤭 ${commands.size} Commands Loaded`);
}

// Gestion des avertissements utilisateur
function getUserWarnings(jid, userId) {
  const key = `${jid}_${userId}`;
  if (!userWarnings.has(key)) {
    userWarnings.set(key, {
      antilink: 0,
      antispam: 0,
      messages: [],
      lastReset: Date.now()
    });
  }
  return userWarnings.get(key);
}

function resetUserWarnings(jid, userId = null) {
  if (userId) {
    const key = `${jid}_${userId}`;
    userWarnings.delete(key);
  } else {
    for (const [key] of userWarnings) {
      if (key.startsWith(`${jid}_`)) {
        userWarnings.delete(key);
      }
    }
  }
}
       // ==================== FONCTIONS DE PROTECTION ====================
async function checkSpam(msg, jid, sender, body, groupSettings) {
  try {
    if (isOwner(msg)) return;

    const senderIsAdmin = await isAdmin(sock, jid, sender);
    if (senderIsAdmin) return;

    const warnings = getUserWarnings(jid, sender);
    const now = Date.now();
    
    warnings.messages = warnings.messages.filter(m => now - m.timestamp < 5000);
    warnings.messages.push({ timestamp: now, body: body });

    if (warnings.messages.length > 5) {
      await safeSend(sock, jid, { delete: msg.key });
      warnings.antispam++;
      
      const warningMsg = `💔 @${sender.split('@')[0]} - Spam Detected!\nWarnings: ${warnings.antispam}/${groupSettings.antispam_threshold || 3}`;
      
      await safeSend(sock, jid, { 
        text: warningMsg,
        mentions: [sender]
      });

      if (warnings.antispam >= (groupSettings.antispam_threshold || 3)) {
        try {
          await sock.groupParticipantsUpdate(jid, [sender], "remove");
          await safeSend(sock, jid, { 
            text: `🤭 @${sender.split('@')[0]} Removed For Spamming In The Party.`,
            mentions: [sender]
          });
        } catch (kickError) {
          console.error('💔 Cannot Remove User:', kickError.message);
        }
      }
    }
  } catch (error) {
    console.error('💔 Spam Protection Error:', error.message);
  }
}

async function checkLinks(msg, jid, sender, body, groupSettings) {
  try {
    if (isOwner(msg)) return;

    const senderIsAdmin = await isAdmin(sock, jid, sender);
    if (senderIsAdmin) return;

    const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\/[^\s]*)/gi;
    if (linkRegex.test(body)) {
      await safeSend(sock, jid, { delete: msg.key });
      const warnings = getUserWarnings(jid, sender);
      warnings.antilink++;
      
      const warningMsg = `💔 @${sender.split('@')[0]} - Links Are Not Allowed In My Party !\nWarnings: ${warnings.antilink}/${groupSettings.antilink_threshold || 3}`;
      
      await safeSend(sock, jid, { 
        text: warningMsg,
        mentions: [sender]
      });

      if (warnings.antilink >= (groupSettings.antilink_threshold || 3)) {
        try {
          await sock.groupParticipantsUpdate(jid, [sender], "remove");
          await safeSend(sock, jid, { 
            text: `🤭 @${sender.split('@')[0]} Removed For Sending Links.`,
            mentions: [sender]
          });
        } catch (kickError) {
          console.error('💔 Cannot Remove User:', kickError.message);
        }
      }
    }
  } catch (error) {
    console.error('💔 Link Protection Error:', error.message);
  }
}

async function checkMentions(msg, jid, sender, body, groupSettings) {
  try {
    if (isOwner(msg)) return;

    const senderIsAdmin = await isAdmin(sock, jid, sender);
    if (senderIsAdmin) return;

    const mentions = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const hasMassMention = mentions.length >= 3;
    const hasGroupMention = body.includes('@everyone') || body.includes('@all');
    
    if (hasMassMention || hasGroupMention) {
      await safeSend(sock, jid, { delete: msg.key });
      const warningMsg = `💔 @${sender.split('@')[0]} - Mass Mentions Are Not Allowed Darling!`;
      await safeSend(sock, jid, { text: warningMsg, mentions: [sender] });
    }
  } catch (error) {
    console.error('💔 Mention Protection Error:', error.message);
  }
}

async function checkMassTags(msg, jid, sender, body, groupSettings) {
  try {
    if (isOwner(msg)) return;

    const senderIsAdmin = await isAdmin(sock, jid, sender);
    if (senderIsAdmin) return;

    const mentions = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentions.length >= 5) {
      await safeSend(sock, jid, { delete: msg.key });
      const warningMsg = `💔 @${sender.split('@')[0]} - Too Many Tags Darling !`;
      await safeSend(sock, jid, { text: warningMsg, mentions: [sender] });
    }
  } catch (error) {
    console.error('💔 Tag Protection Error:', error.message);
  }
}

// ==================== GESTION DES GROUPES ====================
async function handleGroupParticipantsUpdate(event) {
  const { id, participants, action } = event;
  
  try {
    const groupSettings = await Database.getGroupSettings(id);
    
    if (action === 'demote' && groupSettings.antidemote_enabled) {
      await handleAntidemote(event);
    }
    
    if (action === 'promote' && groupSettings.antipromote_enabled) {
      await handleAntipromote(event);
    }
    
    if (action === 'add' && groupSettings.welcome_enabled) {
      await sendWelcomeMessageToGroup(event, groupSettings);
    }
    
    if (action === 'remove' && groupSettings.goodbye_enabled) {
      await sendGoodbyeMessageToGroup(event, groupSettings);
    }
  } catch (error) {
    console.error('💔 Group Update Error:', error.message);
  }
}

async function handleAntidemote(event) {
  const { id, participants } = event;
  
  console.log(`🛡️ Anti-Demote Activated For ${id}`);
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  for (const participant of participants) {
    try {
      await sock.groupParticipantsUpdate(id, [participant], 'promote');
      console.log(`🤭🎉 Admin Restored: ${participant.split('@')[0]}`);
    } catch (error) {
      console.error('❌ Anti-Demote Error:', error.message);
    }
  }
}

async function handleAntipromote(event) {
  const { id, participants } = event;
  
  console.log(`🛡️ Anti-Promote Activated For ${id}`);
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  for (const participant of participants) {
    try {
      await sock.groupParticipantsUpdate(id, [participant], 'demote');
      console.log(`✅ Promotion Cancelled: ${participant.split('@')[0]}`);
    } catch (error) {
      console.error('❌ Anti-Promote Error:', error.message);
    }
  }
}

async function sendWelcomeMessageToGroup(event, groupSettings) {
  const { id, participants } = event;
  
  try {
    const metadata = await sock.groupMetadata(id);
    
    for (const participant of participants) {
      const welcomeText = groupSettings.welcome_message || 
        `🤭🎉 Welcome @${participant.split('@')[0]} To ${metadata.subject}!\n` +
        `We Are Now ${metadata.participants.length} Freaky Members.`;
      
      await sock.sendMessage(id, {
        text: welcomeText,
        mentions: [participant]
      });
    }
  } catch (error) {
    console.error('💔 Welcome Message Error:', error.message);
  }
}

async function sendGoodbyeMessageToGroup(event, groupSettings) {
  const { id, participants } = event;
  
  try {
    const metadata = await sock.groupMetadata(id);
    
    for (const participant of participants) {
      const goodbyeText = groupSettings.goodbye_message || 
        `😂💔 @${participant.split('@')[0]} Has Left ${metadata.subject}.\n` +
        `Not Place For Dormant Ass ! We Are Now ${metadata.participants.length} Freaky Members.`;
      
      await sock.sendMessage(id, {
        text: goodbyeText,
        mentions: [participant]
      });
    }
  } catch (error) {
    console.error('💔 Goodbye Message Error:', error.message);
  }
}
        // ==================== FONCTIONS AUTOMATIQUES ====================
async function sendWelcomeMessage() {
  if (welcomeMessageSent || welcomeMessageSentSession) {
    console.log('⚠️ Welcome message already sent for this session, skipping...');
    return;
  }
  
  if (!sock || !isConnected) {
    console.log('⚠️ Not fully connected yet, waiting...');
    return;
  }
  
  try {
    console.log('📤 Attempting to send welcome message...');
    
    const userSettings = await Database.getUserSettings();
    const welcomeMessage = 
      `> *𝐋𝐎𝐕𝐄 - 𝐗𝐃 - 𝐈𝐒 - 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃*\n` +
      `> *𝐁𝐨𝐭 𝐍𝐚𝐦𝐞:* [${userSettings.bot_name}]\n` +
      `> *𝐂𝐫𝐞́𝐚𝐭𝐞𝐮𝐫:* [${userSettings.creator || config.owner}]\n` +
      `> *𝐏𝐫𝐞́𝐟𝐢𝐱𝐞:* [${userSettings.prefix}]\n` +
      `> *𝐌𝐨𝐝𝐞:* [${userSettings.bot_mode}]\n` +
      `> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐃𝐚𝐫𝐤𝐌𝐨𝐝𝐬\n` +
      `> 𝐓𝐡𝐞 𝐏𝐨𝐰𝐞𝐫 𝐎𝐟 𝐋𝐨𝐯𝐞 𝐈𝐧 𝐘𝐨𝐮𝐫 𝐇𝐚𝐧𝐝\'𝐬`;
      
    if (config.owner) {
      const ownerJid = `${config.owner}@s.whatsapp.net`;
      await sock.sendMessage(ownerJid, { 
        image: { 
          url: userSettings.menu_image 
        }, 
        caption: welcomeMessage 
      });
      console.log('❤️ Welcome message sent successfully to owner');
    }
    
    welcomeMessageSent = true;
    welcomeMessageSentSession = true;
    
    console.log('❤️ Welcome Message Sent - Session secured');
    
  } catch (error) {
    console.error('💔 Welcome Message Error:', error.message);
  }
}

async function handleStatusMessage(message) {
  try {
    if (config.autostatus) {
      const { handleAutoStatus } = await import('./commands/autostatus.js');
      await handleAutoStatus(sock, { messages: [message] });
    }
  } catch (error) {
    console.error('💔 Status Handling Error:', error.message);
  }
}

async function handleAutoFeatures(msg) {
  try {
    const { handleAutowriteMessage } = await import('./commands/autowrite.js');
    if (handleAutowriteMessage) {
      await handleAutowriteMessage(sock, msg);
    }
  } catch (error) {
    // Silent fail
  }

  try {
    const { handleAutoReact } = await import('./commands/autoreact.js');
    if (handleAutoReact) {
      await handleAutoReact(sock, msg);
    }
  } catch (error) {
    // Silent fail
  }
}

// ==================== GESTION DES MESSAGES ====================
async function handleMessage(msg) {
  if (!msg.message) return;

  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const isGroup = jid?.endsWith('@g.us');
  
  const body = msg.message.conversation || 
              msg.message.extendedTextMessage?.text || 
              msg.message.imageMessage?.caption || '';

  const userSettings = await Database.getUserSettings();
  const isCommand = body.startsWith(userSettings.prefix);

  if (msg.key.fromMe && !isCommand) {
    return;
  }

  console.log(`❤️ Message De ${msg.key.fromMe ? 'BOT' : sender}: ${body.substring(0, 50)}...`);
  if (isCommand) {
    console.log(`🔍 Commande Détectée: ${body}`);
  }

  if (msg.message.protocolMessage?.type === 0) {
    try {
      const { handleMessageRevocation } = await import('./commands/antidelete.js');
      await handleMessageRevocation(msg, sock);
    } catch (error) {
      console.error('💔 Antidelete Error:', error.message);
    }
    return;
  }

  try {
    const { storeMessage } = await import('./commands/antidelete.js');
    await storeMessage(msg, sock);
  } catch (error) {
    // Silent fail
  }

  if (!isCommand && !msg.key.fromMe) {
    await handleAutoFeatures(msg);
  }

  if (isCommand) {
    await handleCommand(msg, body, userSettings);
  }

  if (isGroup && !msg.key.fromMe) {
    await applyGroupProtections(msg, userSettings);
  }
}

async function applyGroupProtections(msg, userSettings) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const body = msg.message.conversation || msg.message.extendedTextMessage?.text || '';

  const groupSettings = await Database.getGroupSettings(jid);

  if (groupSettings.antispam_enabled) {
    await checkSpam(msg, jid, sender, body, groupSettings);
  }

  if (groupSettings.antilink_enabled) {
    await checkLinks(msg, jid, sender, body, groupSettings);
  }

  if (groupSettings.antimention_enabled) {
    await checkMentions(msg, jid, sender, body, groupSettings);
  }

  if (groupSettings.antitag_enabled) {
    await checkMassTags(msg, jid, sender, body, groupSettings);
  }
}

// ==================== GESTION DES COMMANDES ====================
async function handleCommand(msg, body, userSettings) {
  const jid = msg.key.remoteJid;
  const args = body.slice(userSettings.prefix.length).trim().split(/\s+/);
  const commandName = args[0].toLowerCase();
  
  try {
    const command = commands.get(commandName);
    if (!command) {
      return;
    }

    const permission = await checkPermissions({
      sock: sock, 
      msg, 
      userSettings, 
      commandName
    });

    if (!permission.allowed) {
      let errorMsg = '';
      switch (permission.reason) {
        case 'ACCESS_DENIED':
          console.log(`💔 Command ignored in private mode`);
          return;
        case 'OWNER_ONLY':
          errorMsg = '⭐ *┈┈┈┈┈┈┈┈┈┈┈┈┈┈*\n' +
                     '‣ *L O V E - X D*\n' +
                     '┈┈┈┈┈┈┈┈┈┈┈┈┈┈\n' +
                     '🤭 *Access Denied*\n\n' +
                     '🍷 *This Command Is Reserved For*\n' +
                     '🎉 *My Beloved Master Only*\n\n' +
                     '╰─➤ *Love-XD* ❤️';
          break;
        case 'PREMIUM_ONLY':
          errorMsg = '⭐ *┈┈┈┈┈┈┈┈┈┈┈┈┈┈*\n' +
                     '‣ *L O V E - X D*\n' +
                     '┈┈┈┈┈┈┈┈┈┈┈┈┈┈\n' +
                     '💎 *Premium Feature*\n\n' +
                     '😴 *Upgrade To Premium*\n' +
                     '💎 *Contact My Owner Now*\n\n' +
                     '╰─➤ *Love-XD* 🤭';
          break;
        case 'ADMIN_ONLY':
          errorMsg = '⭐ *┈┈┈┈┈┈┈┈┈┈┈┈┈┈*\n' +
                     '‣ *L O V E - X D*\n' +
                     '┈┈┈┈┈┈┈┈┈┈┈┈┈┈\n' +
                     '❤️ *Admin Only*\n\n' +
                     '🍷 *Group Admins Only*\n' +
                     '❤️ *Can Use This Command*\n\n' +
                     '╰─➤ *Love-XD* 🤭';
          break;
        default:
          errorMsg = '⭐ *┈┈┈┈┈┈┈┈┈┈┈┈┈┈*\n' +
                     '‣ *L O V E - X D*\n' +
                     '┈┈┈┈┈┈┈┈┈┈┈┈┈┈\n' +
                     '💔 *Permission Denied*\n\n' +
                     '😴 *You Cannot Use This*\n' +
                     '💔 *Command Right Now*\n\n' +
                     '╰─➤ *Love-XD* 🤭';
      }
      await safeSend(sock, jid, { text: errorMsg });
      return;
    }

    const groupSettings = jid.endsWith('@g.us') ? await Database.getGroupSettings(jid) : {};

    await command.execute({
      sock: sock,
      msg,
      args: args.slice(1),
      phoneNumber: config.owner,
      userSettings,
      groupSettings,
      jid,
      isGroup: jid.endsWith('@g.us'),
      getUserWarnings: (userId) => getUserWarnings(jid, userId),
      resetUserWarnings: (userId) => resetUserWarnings(jid, userId)
    });

    botTracker.incrementCommands(commandName);
    
  } catch (error) {
    console.error('❌ Command error:', error.message);
    
    try {
      await safeSend(sock, jid, { 
        text: `💔 Error: ${error.message}` 
      });
    } catch (sendError) {
      console.error('❌ Cannot send error message:', sendError.message);
    }
  }
}

// ==================== CONNEXION WHATSAPP ====================
async function startBot(usePairing = true) {
  try {
    console.log('🔄 Starting WhatsApp connection...');
    
    const { version } = await fetchLatestBaileysVersion();
    const { state, saveCreds } = await useMultiFileAuthState('./session');

    sock = makeWASocket({
      version,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" })),
      },
      printQRInTerminal: false,
      browser: ['Ubuntu', 'Chrome', '20.0.04'],
      logger: pino({ level: 'silent' }),
      markOnlineOnConnect: true,
      generateHighQualityLinkPreview: true,
      syncFullHistory: true
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('groups.update', async (updates) => {
      for (const update of updates) {
        try {
          const metadata = await sock.groupMetadata(update.id);
          groupCache.set(update.id, metadata);
        } catch (e) {
          console.error('❌ Group cache error:', e.message);
        }
      }
    });

    if (usePairing && !state.creds.registered) {
      setTimeout(async () => {
        try {
          console.log('❤️ Demande Du Code Pair...');
          
          const customBrand = "GOATSMODS";
          let code;
          
          try {
            code = await sock.requestPairingCode(config.owner, customBrand);
            console.log(`❤️ Marque personnalisée appliquée: ${customBrand}`);
          } catch (brandError) {
            console.log(`💔 Marque personnalisée non supportée, utilisation par défaut`);
            code = await sock.requestPairingCode(config.owner);
          }
          
          const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;
          console.log(`\n❤️ Your Pairing Code : ${formattedCode}\n`);
          console.log("😴 Entrez ce code dans WhatsApp → Appareils liés");
          
        } catch (error) {
          console.error('💔 Erreur pairing:', error.message);
        }
      }, 3000);
    }

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;
      
      console.log(`🎉 Connection update:`, connection);

      if (connection === 'open') {
        console.log('❤️ WhatsApp connected successfully');
        
        const wasConnected = isConnected;
        isConnected = true;
        
        if (!wasConnected) {
          console.log('🆕 First time connection detected');
          connectionAttempts = 0;
          
          if (!welcomeMessageSent && !welcomeMessageSentSession) {
            botTracker.start();
          }
          
          setTimeout(async () => {
            await sendWelcomeMessage();
          }, 2000);
        } else {
          console.log('🔄 Reconnection detected, keeping session state');
        }
        
      } else if (connection === 'close') {
        isConnected = false;
        
        const error = lastDisconnect?.error;
        const statusCode = error?.output?.statusCode;
        
        console.log(`💔 Connection closed:`, error?.message);
        
        if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
          console.log('💔 Session logged out');
          welcomeMessageSent = false;
          welcomeMessageSentSession = false;
          connectionAttempts = 0;
          return;
        }
        
        console.log('🔄 Reconnecting...');
        
        connectionAttempts++;
        
        setTimeout(() => {
          startBot(usePairing);
        }, 3000);
      }
    });

    await loadCommands();

    sock.ev.on('messages.upsert', async ({ messages }) => {
      for (const message of messages) {
        if (message.key.remoteJid === 'status@broadcast') {
          await handleStatusMessage(message);
          continue;
        }
        
        await handleMessage(message);
      }
    });

    sock.ev.on('group-participants.update', async (event) => {
      await handleGroupParticipantsUpdate(event);
    });

  } catch (error) {
    console.error('❌ Bot startup error:', error);
    setTimeout(() => startBot(usePairing), 5000);
  }
}

async function checkDashboardCommands() {
  setInterval(async () => {
    try {
      console.log('🔍 Checking dashboard commands...');
    } catch (error) {
      // Silent fail
    }
  }, 5 * 60 * 1000);
}

async function listenForDashboardCommands() {
  setInterval(async () => {
    try {
      const response = await fetch('https://steph-api.vercel.app/api/check-commands', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: config.owner })
      });
      
      if (response.ok) {
        const { commands } = await response.json();
        for (const cmd of commands || []) {
          if (cmd.type === 'BROADCAST') {
            await sock.sendMessage(`${config.owner}@s.whatsapp.net`, {
              text: cmd.message
            });
          }
        }
      }
    } catch (error) {
      // Silent fail
    }
  }, 5 * 60 * 1000);
}

// ==================== DÉMARRAGE ====================

http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('🤖 Bot WhatsApp En Fonctionnement!');
}).listen(config.port, () => {
  console.log(chalk.blue(`🌐 Serveur démarré sur le port ${config.port}`));
});

process.on('SIGINT', async () => {
  console.log(chalk.yellow('\n🛑 Arrêt du bot...'));
  botTracker.stop();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log(chalk.yellow('\n🛑 Arrêt du bot...'));
  botTracker.stop();
  process.exit(0);
});

startBot(true);
listenForDashboardCommands();
checkDashboardCommands();